<template>
    <div id="all-products">
        <h1>All Data</h1>
         <!-- <p><router-link :to="{ name: 'create_product' }" class="btn btn-primary">Create Data</router-link></p> -->
   
		Sorting Berdasar Cabang Olahraga	<input type="text" itemid="submit" id="CABOR" onkeyup="myFunction()" placeholder="Sorting data Cabang olahraga.." title="CABOR" value="">


<!-- <input class="form-control" type="text" id="" onkeyup="searchedProducts()" placeholder="Search.." title="Type in"> -->
        <div class="form-group">
    <input type="text" name="search" v-model="productSearch" placeholder="Search" class="form-control" v-on:keyup="searchedProducts()">


        </div>

        <table id="tgj" class="table table-hover">
            <thead>
            <tr>
                <td>ID</td>
                <td>User ID</td>
                <td>Title</td>
                <td>Body</td>
                <td>Actions</td>

            </tr>
            </thead>

            <tbody>

                <tr id="" v-for="product in products">
                    <td>{{ product.id }}</td>
                    <td>{{ product.user_id }}</td>
                    <td>{{ product.title }}</td>
                    <td>{{ product.body }}</td>
                    <td>
                        <router-link :to="{name: 'edit_product', params: { id: product.id }}" class="btn btn-primary">Edit</router-link>
                        <router-link :to="{name: 'delete_product', params: { id: product.id }}" class="btn btn-danger">Delete</router-link>
                    </td>
                    <!--  -->

                    <!--  -->
                </tr>
                
            </tbody>
        </table>
    </div>
</template>

<script>
 

    export default{
          components: {
    
  },
    
 
        data()
        {
            return{
                filter: "",
                search: "",
                products: [],

          selectVal: {

      id: undefined,
      user_id: undefined,
      title: undefined
    }
                
            }
            
        },

        created: function()
        {
            this.fetchProductData();
            this.MyFunction();
        },
// 

// Add computed section:

//  
        methods: {
            fetchProductData: function()
            {
                this.$http.get('https://gorest.co.in/public/v2/posts').then((response) => {
                    this.products = response.body;
                    this.originalProducts = this.products;
                }, (response) => {

                });
            },
        },
// 
    }   
          function myFunction() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("CABOR");
  function submitform() {
if (validate()) // Calling validate function
{
	function emptySelectBoxById(eid, value, text) {
    document.getElementById(eid).innerHTML = "<option value='" + value + "'>" + text + "</option>";
}
getElementsByTagName('option')[0].selected
document.getElementById("CABOR").submit();
}
}
  filter = input.value.toUpperCase();
  table = document.getElementById("tgj");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[9];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
// 
    //             searchProducts: function()
    //         {
    //             if(this.productSearch == '')
    //             {
    //                 this.products = this.originalProducts;
    //                 return;
    //             }

    //             var searchedProducts = [];
    //             for(var i = 0; i < this.originalProducts.length; i++)
    //             {
    //                 var productName = this.product[i]['name'].toLowerCase();
    //                 if(productName.indexOf(this.productSearch.toLowerCase()) >= 0 )
    //                 {
    //                     searchedProducts.push(this.searchedProducts[i]);
    //                 }
    //             }

    //             this.products = searchedProducts;
    //         }
    //     }
        
    // }
</script>
